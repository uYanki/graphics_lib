﻿#include "Point2.h"
#include <math.h>


Point2::Point2()
{
}

Point2::Point2(double x, double y)
{
	value[0] = x;
	value[1] = y;
}


Point2::~Point2()
{
}
