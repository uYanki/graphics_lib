﻿#include "EdgeTableItem.h"



EdgeTableItem::EdgeTableItem(double X, double DX, double YMAX) :x(X), dx(DX), Ymax(YMAX)
{
}


EdgeTableItem::~EdgeTableItem()
{
}
