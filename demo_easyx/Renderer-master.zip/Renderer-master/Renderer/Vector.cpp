﻿#include "Vector.h"



Vector::Vector()
{
}


Vector::~Vector()
{
}
