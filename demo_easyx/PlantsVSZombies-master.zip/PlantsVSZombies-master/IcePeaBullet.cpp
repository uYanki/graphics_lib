#include "IcePeaBullet.h"

IcePeaBullet::IcePeaBullet(int po_x, int po_y) :Bullet(po_x, po_y, 20, "snowBullet.png",2, "Bullet_bk.jpg")
{
}

IcePeaBullet::~IcePeaBullet()
{
}
