#pragma once
#include"Bullet.h"
class IcePeaBullet :public Bullet
{
public:
	IcePeaBullet(int po_x, int po_y);
	~IcePeaBullet();
};