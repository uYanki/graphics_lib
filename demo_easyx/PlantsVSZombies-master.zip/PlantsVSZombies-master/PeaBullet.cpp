#include "PeaBullet.h"

PeaBullet::PeaBullet(int po_x, int po_y):Bullet(po_x, po_y, 20, "Bullet.jpg",1, "Bullet_bk.jpg")
{
}

PeaBullet::~PeaBullet()
{
}
