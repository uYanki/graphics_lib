#pragma once
#include "Bullet.h"
class PeaBullet : public Bullet
{
public :
	PeaBullet(int po_x, int po_y);
	~PeaBullet();
};

