#pragma once
#include "Zombie.h"
class BucketheadZombie :public Zombie
{
public:
	BucketheadZombie(int as = 0, int ms = 0, int po_x = 0, int po_y = 0);
	~BucketheadZombie();
};

